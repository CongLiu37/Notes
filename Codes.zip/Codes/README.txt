Content:

1. Differential expression analysis of RNA-seq with reference genome
2. Search for specific motif in promoters
3. Rarefaction analysis
4. Genome/Metagenome assembly, binning and assembly quality assessment
5. Gene prediction
6. Machine learning in scikit-learn, python
