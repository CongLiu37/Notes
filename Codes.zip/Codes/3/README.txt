Rarefaction analysis

(1) SamplingEffortSimulation
Simulate reduced sampling effort.

(2) ComputeDiversity
Compute diversity index. 
Index can be richness, exponential Shannon index, Gini Simpson index.

(3) ComputeDistance
Compute distance/dissimilarity between abundance distribution of full and reduced sampling effort.
Distance/dissimilarity can be Bray-Curtis, Kullback-Leibler, Jensen-Shannon.

(4) CI
Compute 0.95 confidence interval by 1000 bootstrap samples.
